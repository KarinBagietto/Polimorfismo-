package br.edu.fatecpg.poli.view;
import br.edu.fatecpg.poli.model.*;
public class MainVeiculo {
	public static void main(String[] args) {
		Bicicleta bicicleta = new Bicicleta();
		Carro car = new Carro();
		
		bicicleta.mover();
		
	}
}
