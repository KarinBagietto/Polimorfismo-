package br.edu.fatecpg.poli.model;

public class Calculadora{
	  public int somar(int v1,int v2){
		return v1+v2;
	} 
	public int somar(int v1,int v2,int v3){
		return v1+v2+v3;
	}
	public double somar(double v1,double v2){
		return v1+v2;
	}
}
