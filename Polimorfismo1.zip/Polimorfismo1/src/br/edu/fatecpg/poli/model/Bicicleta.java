package br.edu.fatecpg.poli.model;

public class Bicicleta implements Veiculo{
	@Override
	public void mover() {
		System.out.println("A bicicleta está pedalando");
	}
}
