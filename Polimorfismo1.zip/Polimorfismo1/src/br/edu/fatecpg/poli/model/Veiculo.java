package br.edu.fatecpg.poli.model;

public interface Veiculo {
	public void mover();
	}
