package br.edu.fatecpg.poli.model;

public class Carro implements Veiculo {

	@Override
	public void mover() {
		System.out.println("Carro esta dirigindo");
	}
}
